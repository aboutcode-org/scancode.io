// Copyright (c) Anish Athalye (me@anishathalye.com)
// Released under GPLv3. See the included LICENSE.txt for details

// asynchronously send anonymized statistics
void send_stats(unsigned int retries);
