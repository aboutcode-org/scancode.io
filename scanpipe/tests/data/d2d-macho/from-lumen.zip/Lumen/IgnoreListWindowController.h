// Copyright (c) Anish Athalye (me@anishathalye.com)
// Released under GPLv3. See the included LICENSE.txt for details

#import <Cocoa/Cocoa.h>

@interface IgnoreListWindowController : NSWindowController

@end
