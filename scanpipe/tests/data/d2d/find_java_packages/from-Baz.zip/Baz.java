package org.apache.biz;

class Baz {}