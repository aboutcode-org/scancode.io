# frozen_string_literal: true

module Sentry
  module DelayedJob
    VERSION = "5.22.1"
  end
end
