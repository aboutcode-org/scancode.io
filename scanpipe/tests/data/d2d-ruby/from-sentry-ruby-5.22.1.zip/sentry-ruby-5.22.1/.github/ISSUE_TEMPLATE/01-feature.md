---
name: 💡 Feature Request
about: Propose new functionality for the SDK
type: Feature
---

**Describe the idea**

**Why do you think it's beneficial to most of the users**

**Possible implementation**
