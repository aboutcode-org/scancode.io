---
name: 💡 Improvement
about: Propose an improvement for existing functionality of the SDK
type: Improvement
---

**Describe the idea**

**Why do you think it's beneficial to most of the users**

**Possible implementation**
