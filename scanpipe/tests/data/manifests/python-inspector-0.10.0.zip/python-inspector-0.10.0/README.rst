python-inspector - inspect Python packages dependencies and metadata
=====================================================================

The goal of python-inspector is to be a comprehensive library
that can handle every style of Python package layouts, manifests and lockfiles.

